# Geekjob.ru Parser

Эффективный Python-парсер для сбора вакансий с сайта Geekjob.ru. Заменяет тяжёлое Node.js/Playwright решение на лёгкий и быстрый Python-скрипт.

## 🚀 Особенности

- **Лёгкий и быстрый** - использует requests + BeautifulSoup вместо браузерной эмуляции
- **Полное извлечение данных** - собирает всю доступную информацию с каждой страницы вакансии
- **Интеграция с SQLite** - совместим с существующей базой данных Next.js приложения
- **Надёжность** - обработка ошибок, повторные попытки, логирование
- **Гибкость** - настраиваемые параметры поиска и задержки
- **Планировщик** - легко интегрируется с cron или task scheduler

## 📋 Требования

- Python 3.7+
- Зависимости из `requirements.txt`

## 🛠 Установка

1. **Клонируйте или скопируйте файлы:**
   ```bash
   # Скопируйте файлы в папку проекта
   cp geekjob_parser.py /path/to/your/project/
   cp requirements.txt /path/to/your/project/
   ```

2. **Установите зависимости:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Сделайте скрипт исполняемым (Linux/Mac):**
   ```bash
   chmod +x geekjob_parser.py
   ```

## 🎯 Использование

### Базовое использование

```bash
# Парсинг дизайнерских вакансий в database.db
python geekjob_parser.py

# Указание пути к базе данных
python geekjob_parser.py --db /path/to/database.db

# Поиск по другому запросу
python geekjob_parser.py --query "python разработчик"

# Ограничение количества страниц
python geekjob_parser.py --pages 5

# Увеличение задержки между запросами
python geekjob_parser.py --delay 2.0

# Подробный вывод
python geekjob_parser.py --verbose
```

### Все параметры

```bash
python geekjob_parser.py \
  --db database.db \
  --query "дизайнер" \
  --pages 10 \
  --delay 1.0 \
  --verbose
```

### Параметры командной строки

| Параметр | Короткий | Описание | По умолчанию |
|----------|----------|----------|--------------|
| `--db` | | Путь к SQLite базе данных | `database.db` |
| `--query` | `-q` | Поисковый запрос | `дизайнер` |
| `--pages` | `-p` | Максимальное количество страниц | `10` |
| `--delay` | `-d` | Задержка между запросами (сек) | `1.0` |
| `--verbose` | `-v` | Подробный вывод | `False` |

## 🔄 Автоматизация

### Cron (Linux/Mac)

```bash
# Редактировать crontab
crontab -e

# Запуск каждые 4 часа
0 */4 * * * /usr/bin/python3 /path/to/geekjob_parser.py --db /path/to/database.db

# Запуск каждый день в 9:00
0 9 * * * /usr/bin/python3 /path/to/geekjob_parser.py --db /path/to/database.db --query "дизайнер"
```

### Task Scheduler (Windows)

1. Откройте Task Scheduler
2. Создайте новую задачу
3. Укажите программу: `python.exe`
4. Аргументы: `/path/to/geekjob_parser.py --db /path/to/database.db`
5. Настройте расписание

### Systemd Timer (Linux)

Создайте файл `/etc/systemd/system/geekjob-parser.service`:

```ini
[Unit]
Description=Geekjob Parser
After=network.target

[Service]
Type=oneshot
User=your-user
WorkingDirectory=/path/to/project
ExecStart=/usr/bin/python3 geekjob_parser.py --db database.db
```

Создайте файл `/etc/systemd/system/geekjob-parser.timer`:

```ini
[Unit]
Description=Run Geekjob Parser every 4 hours
Requires=geekjob-parser.service

[Timer]
OnCalendar=*-*-* 00/4:00:00
Persistent=true

[Install]
WantedBy=timers.target
```

Активируйте:

```bash
sudo systemctl enable geekjob-parser.timer
sudo systemctl start geekjob-parser.timer
```

## 📊 Извлекаемые данные

Парсер извлекает следующие поля для каждой вакансии:

### Основные поля
- `external_id` - Уникальный ID вакансии (geekjob_123456)
- `source` - Источник ('geekjob')
- `url` - Полный URL вакансии
- `title` - Название вакансии
- `company` - Название компании
- `location` - Локация
- `description` - Краткое описание
- `published_at` - Дата публикации

### Детальная информация
- `full_description` - Полное описание вакансии
- `requirements` - Требования к кандидату
- `tasks` - Задачи и обязанности
- `conditions` - Условия работы
- `benefits` - Льготы и преимущества

### Зарплата
- `salary_min` - Минимальная зарплата
- `salary_max` - Максимальная зарплата
- `salary_currency` - Валюта (RUB, USD, EUR)

### Дополнительно
- `company_logo` - URL логотипа компании
- `company_url` - URL страницы компании
- `employment_type` - Тип занятости
- `experience_level` - Уровень опыта
- `remote_type` - Тип работы (remote/office/hybrid)

## 📝 Логирование

Парсер ведёт подробные логи:

- **Консоль** - основная информация о прогрессе
- **Файл** `geekjob_parser.log` - детальные логи для отладки

Уровни логирования:
- `INFO` - основная информация
- `DEBUG` - детальная отладочная информация (с флагом `--verbose`)
- `WARNING` - предупреждения
- `ERROR` - ошибки

## 🔧 Интеграция с Next.js

Парсер полностью совместим с существующей SQLite базой данных Next.js приложения:

1. **Структура таблицы** - использует ту же схему `vacancies`
2. **UPSERT логика** - обновляет существующие записи по `external_id`
3. **Безопасность** - не мешает работе Next.js сервера
4. **Кодировка** - корректно работает с UTF-8

### Пример интеграции

```bash
# В папке Next.js проекта
cd /path/to/job-filter-mvp

# Запуск парсера с существующей базой
python geekjob_parser.py --db database.db --query "дизайнер"

# Проверка результатов в Next.js админке
npm run dev
# Открыть http://localhost:3000/admin
```

## 📈 Производительность

### Преимущества перед Playwright

| Характеристика | Python Parser | Playwright |
|----------------|---------------|------------|
| **Память** | ~50MB | ~200-500MB |
| **Скорость** | ~2-3 сек/вакансия | ~5-10 сек/вакансия |
| **CPU** | Низкое | Высокое |
| **Стабильность** | Высокая | Средняя |
| **Простота** | Высокая | Низкая |

### Рекомендуемые настройки

- **Задержка**: 1-2 секунды между запросами
- **Страницы**: 5-10 для регулярного обновления
- **Частота**: каждые 4-6 часов
- **Мониторинг**: проверка логов раз в день

## 🚨 Обработка ошибок

Парсер устойчив к различным типам ошибок:

- **Сетевые ошибки** - повторные попытки, таймауты
- **Изменения HTML** - множественные селекторы
- **Блокировки** - User-Agent, задержки
- **База данных** - транзакции, откат изменений

### Коды выхода

- `0` - Успешное выполнение
- `1` - Критическая ошибка или больше ошибок чем успешных операций
- `130` - Прерывание пользователем (Ctrl+C)

## 🔍 Отладка

### Проблемы с подключением

```bash
# Проверка доступности сайта
curl -I https://geekjob.ru

# Тест с подробными логами
python geekjob_parser.py --verbose --pages 1
```

### Проблемы с базой данных

```bash
# Проверка структуры таблицы
sqlite3 database.db ".schema vacancies"

# Проверка данных
sqlite3 database.db "SELECT COUNT(*) FROM vacancies WHERE source='geekjob'"
```

### Проблемы с парсингом

```bash
# Тест на одной странице
python geekjob_parser.py --pages 1 --verbose

# Проверка конкретного запроса
python geekjob_parser.py --query "тест" --pages 1 --verbose
```

## 📞 Поддержка

При возникновении проблем:

1. **Проверьте логи** в файле `geekjob_parser.log`
2. **Запустите с флагом** `--verbose` для детальной информации
3. **Проверьте доступность** сайта Geekjob.ru
4. **Убедитесь в корректности** пути к базе данных

## 🔄 Обновления

Для обновления парсера:

1. Сохраните текущие настройки
2. Замените файл `geekjob_parser.py`
3. Обновите зависимости: `pip install -r requirements.txt --upgrade`
4. Протестируйте на небольшом количестве страниц

---

**Автор**: AI Assistant  
**Версия**: 1.0  
**Дата**: 2025-01-02
