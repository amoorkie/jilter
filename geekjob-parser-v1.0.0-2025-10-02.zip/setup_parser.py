#!/usr/bin/env python3
"""
Скрипт настройки окружения для Geekjob Parser

Автоматически устанавливает зависимости, проверяет совместимость
и настраивает окружение для работы парсера.
"""

import os
import sys
import subprocess
import platform


def check_python_version():
    """Проверка версии Python"""
    print("🐍 Проверка версии Python...")
    
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        print(f"❌ Требуется Python 3.7+, найден {version.major}.{version.minor}")
        return False
    
    print(f"✅ Python {version.major}.{version.minor}.{version.micro} - OK")
    return True


def install_dependencies():
    """Установка зависимостей"""
    print("\n📦 Установка зависимостей...")
    
    if not os.path.exists('requirements.txt'):
        print("❌ Файл requirements.txt не найден")
        return False
    
    try:
        # Проверяем наличие pip
        subprocess.run([sys.executable, '-m', 'pip', '--version'], 
                      check=True, capture_output=True)
        
        # Устанавливаем зависимости
        result = subprocess.run([
            sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'
        ], capture_output=True, text=True)
        
        if result.returncode == 0:
            print("✅ Зависимости установлены успешно")
            return True
        else:
            print(f"❌ Ошибка установки зависимостей: {result.stderr}")
            return False
            
    except subprocess.CalledProcessError as e:
        print(f"❌ Ошибка при установке зависимостей: {e}")
        return False
    except FileNotFoundError:
        print("❌ pip не найден. Установите pip для Python")
        return False


def check_dependencies():
    """Проверка установленных зависимостей"""
    print("\n🔍 Проверка зависимостей...")
    
    required_packages = ['requests', 'beautifulsoup4', 'lxml']
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
            print(f"✅ {package} - установлен")
        except ImportError:
            print(f"❌ {package} - не найден")
            missing_packages.append(package)
    
    return len(missing_packages) == 0


def check_database_path():
    """Проверка пути к базе данных"""
    print("\n🗄️ Проверка базы данных...")
    
    possible_paths = [
        'database.db',
        'src/database.db',
        '../database.db',
        './database.db'
    ]
    
    found_db = None
    for path in possible_paths:
        if os.path.exists(path):
            found_db = path
            print(f"✅ Найдена база данных: {path}")
            break
    
    if not found_db:
        print("⚠️ Существующая база данных не найдена")
        print("Будет создана новая база данных при первом запуске")
    
    return found_db


def create_example_config():
    """Создание примера конфигурации"""
    print("\n⚙️ Создание примера конфигурации...")
    
    config_content = """#!/bin/bash
# Пример скрипта для запуска Geekjob Parser

# Настройки
DATABASE_PATH="database.db"
QUERY="дизайнер"
PAGES=10
DELAY=1.0

# Запуск парсера
python3 geekjob_parser.py \\
    --db "$DATABASE_PATH" \\
    --query "$QUERY" \\
    --pages $PAGES \\
    --delay $DELAY \\
    --verbose

echo "Парсинг завершён. Проверьте логи в geekjob_parser.log"
"""
    
    try:
        with open('run_parser.sh', 'w', encoding='utf-8') as f:
            f.write(config_content)
        
        # Делаем скрипт исполняемым на Unix системах
        if platform.system() != 'Windows':
            os.chmod('run_parser.sh', 0o755)
        
        print("✅ Создан пример скрипта: run_parser.sh")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка создания конфигурации: {e}")
        return False


def create_cron_example():
    """Создание примера cron задачи"""
    print("\n⏰ Создание примера cron задачи...")
    
    current_dir = os.path.abspath('.')
    python_path = sys.executable
    
    cron_content = f"""# Пример cron задачи для Geekjob Parser
# Добавьте эту строку в crontab: crontab -e

# Запуск каждые 4 часа
0 */4 * * * {python_path} {current_dir}/geekjob_parser.py --db {current_dir}/database.db --query "дизайнер" >> {current_dir}/cron.log 2>&1

# Запуск каждый день в 9:00
0 9 * * * {python_path} {current_dir}/geekjob_parser.py --db {current_dir}/database.db --query "дизайнер" >> {current_dir}/cron.log 2>&1

# Запуск каждые 6 часов с подробными логами
0 */6 * * * {python_path} {current_dir}/geekjob_parser.py --db {current_dir}/database.db --query "дизайнер" --verbose >> {current_dir}/cron.log 2>&1
"""
    
    try:
        with open('cron_example.txt', 'w', encoding='utf-8') as f:
            f.write(cron_content)
        
        print("✅ Создан пример cron задачи: cron_example.txt")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка создания cron примера: {e}")
        return False


def run_test():
    """Запуск тестов"""
    print("\n🧪 Запуск тестов...")
    
    if not os.path.exists('test_geekjob_parser.py'):
        print("⚠️ Тестовый файл не найден, пропускаем тесты")
        return True
    
    try:
        result = subprocess.run([
            sys.executable, 'test_geekjob_parser.py'
        ], capture_output=True, text=True, timeout=60)
        
        if result.returncode == 0:
            print("✅ Тесты пройдены успешно")
            print(result.stdout)
            return True
        else:
            print("❌ Тесты не пройдены")
            print(result.stderr)
            return False
            
    except subprocess.TimeoutExpired:
        print("⚠️ Тесты прерваны по таймауту")
        return False
    except Exception as e:
        print(f"❌ Ошибка запуска тестов: {e}")
        return False


def print_usage_instructions():
    """Вывод инструкций по использованию"""
    print("\n📚 Инструкции по использованию:")
    print("=" * 50)
    print()
    print("1. Базовый запуск:")
    print("   python geekjob_parser.py")
    print()
    print("2. С настройками:")
    print("   python geekjob_parser.py --db database.db --query 'python разработчик' --pages 5")
    print()
    print("3. Подробный вывод:")
    print("   python geekjob_parser.py --verbose")
    print()
    print("4. Использование готового скрипта:")
    print("   ./run_parser.sh  # Linux/Mac")
    print("   bash run_parser.sh  # Windows Git Bash")
    print()
    print("5. Настройка автоматического запуска:")
    print("   - Смотрите файл cron_example.txt для Linux/Mac")
    print("   - Используйте Task Scheduler для Windows")
    print()
    print("📋 Дополнительная информация:")
    print("   - Логи сохраняются в geekjob_parser.log")
    print("   - Подробная документация в README_GEEKJOB_PARSER.md")
    print("   - Для отладки используйте флаг --verbose")


def main():
    """Главная функция настройки"""
    print("🚀 Настройка Geekjob Parser")
    print("Версия: 1.0")
    print("Дата: 2025-01-02")
    print("=" * 50)
    
    success = True
    
    # Проверка версии Python
    if not check_python_version():
        success = False
    
    # Установка зависимостей
    if success and not install_dependencies():
        success = False
    
    # Проверка зависимостей
    if success and not check_dependencies():
        success = False
    
    # Проверка базы данных
    if success:
        check_database_path()
    
    # Создание примеров конфигурации
    if success:
        create_example_config()
        create_cron_example()
    
    # Запуск тестов
    if success:
        run_test()
    
    print("\n" + "=" * 50)
    
    if success:
        print("🎉 Настройка завершена успешно!")
        print_usage_instructions()
    else:
        print("❌ Настройка завершена с ошибками.")
        print("Исправьте ошибки и запустите setup_parser.py снова.")
    
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
