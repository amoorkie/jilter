# 🚀 Geekjob Parser - Финальная версия

Эффективный и надёжный Python парсер для сбора вакансий с Geekjob.ru, специально разработанный для интеграции с Next.js проектами.

## 📋 Содержание

- [Особенности](#особенности)
- [Быстрый старт](#быстрый-старт)
- [Интеграция с Next.js](#интеграция-с-nextjs)
- [Настройка автоматизации](#настройка-автоматизации)
- [API и конфигурация](#api-и-конфигурация)
- [Мониторинг и отладка](#мониторинг-и-отладка)
- [Производительность](#производительность)

## ✨ Особенности

### 🎯 Целевая аудитория
- **Дизайнерские вакансии**: UI/UX, продуктовый дизайн, графический дизайн
- **Полное извлечение данных**: описание, требования, задачи, условия, льготы
- **Интеграция с Next.js**: совместимость с существующими проектами

### 🔧 Технические возможности
- **Надёжность**: обработка ошибок, повторные попытки, логирование
- **Производительность**: многопоточность, оптимизированные запросы
- **Гибкость**: настраиваемые параметры, фильтры, форматы вывода
- **Совместимость**: SQLite, PostgreSQL, JSON, CSV

## 🚀 Быстрый старт

### 1. Скачивание и установка

```bash
# Скачайте все файлы парсера
curl -O https://raw.githubusercontent.com/your-repo/geekjob_parser.py
curl -O https://raw.githubusercontent.com/your-repo/requirements.txt
curl -O https://raw.githubusercontent.com/your-repo/setup_parser.py

# Установите зависимости
pip install -r requirements.txt

# Настройте парсер
python setup_parser.py
```

### 2. Первый запуск

```bash
# Простой запуск
python geekjob_parser.py

# С настройками
python geekjob_parser.py --query "UI дизайнер" --pages 5 --verbose

# Тестирование
python test_geekjob_parser.py
```

### 3. Проверка результатов

```bash
# Просмотр базы данных
sqlite3 geekjob_vacancies.db "SELECT title, company FROM vacancies LIMIT 5"

# Статистика
sqlite3 geekjob_vacancies.db "SELECT COUNT(*) as total FROM vacancies"
```

## 🔗 Интеграция с Next.js

### Автоматическая интеграция

```bash
# Поместите integrate_with_nextjs.py в папку с Next.js проектом
python integrate_with_nextjs.py
```

Скрипт автоматически:
- ✅ Найдёт Next.js проект
- ✅ Проверит совместимость базы данных
- ✅ Скопирует файлы парсера
- ✅ Создаст скрипты запуска
- ✅ Обновит package.json
- ✅ Создаст документацию

### Ручная интеграция

```bash
# 1. Скопируйте файлы в проект
mkdir your-nextjs-project/parsers
cp geekjob_parser.py your-nextjs-project/parsers/
cp requirements.txt your-nextjs-project/parsers/

# 2. Установите зависимости
cd your-nextjs-project/parsers
pip install -r requirements.txt

# 3. Настройте путь к базе данных
python geekjob_parser.py --db ../database.db
```

### Использование в Next.js

```javascript
// pages/api/parse-geekjob.js
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export default async function handler(req, res) {
  try {
    const { stdout, stderr } = await execAsync(
      'python parsers/geekjob_parser.py --pages 3',
      { cwd: process.cwd() }
    );
    
    res.status(200).json({ 
      success: true, 
      output: stdout,
      errors: stderr 
    });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
}
```

## ⏰ Настройка автоматизации

### Cron (Linux/Mac)

```bash
# Редактируем crontab
crontab -e

# Добавляем задачи
# Каждые 4 часа
0 */4 * * * cd /path/to/project && python geekjob_parser.py >> cron.log 2>&1

# Каждый день в 9:00
0 9 * * * cd /path/to/project && python geekjob_parser.py --pages 10

# Каждую неделю полный парсинг
0 0 * * 0 cd /path/to/project && python geekjob_parser.py --pages 50 --full-scan
```

### Task Scheduler (Windows)

1. Откройте Task Scheduler
2. Создайте базовую задачу
3. Настройте триггер (например, каждые 4 часа)
4. Действие: Запуск программы
   - Программа: `python.exe`
   - Аргументы: `C:\path\to\geekjob_parser.py`
   - Рабочая папка: `C:\path\to\project`

### Systemd (Linux)

```bash
# Создаём сервис
sudo nano /etc/systemd/system/geekjob-parser.service
```

```ini
[Unit]
Description=Geekjob Parser Service
After=network.target

[Service]
Type=oneshot
User=your-user
WorkingDirectory=/path/to/project
ExecStart=/usr/bin/python3 geekjob_parser.py
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

```bash
# Создаём таймер
sudo nano /etc/systemd/system/geekjob-parser.timer
```

```ini
[Unit]
Description=Run Geekjob Parser every 4 hours
Requires=geekjob-parser.service

[Timer]
OnCalendar=*-*-* 00/4:00:00
Persistent=true

[Install]
WantedBy=timers.target
```

```bash
# Активируем
sudo systemctl enable geekjob-parser.timer
sudo systemctl start geekjob-parser.timer
```

## 🔧 API и конфигурация

### Параметры командной строки

```bash
python geekjob_parser.py [OPTIONS]

Опции:
  --db PATH              Путь к базе данных (по умолчанию: geekjob_vacancies.db)
  --query TEXT           Поисковый запрос (по умолчанию: дизайнер)
  --pages INTEGER        Количество страниц (по умолчанию: 10)
  --delay FLOAT          Задержка между запросами в секундах (по умолчанию: 1.0)
  --timeout INTEGER      Таймаут запросов в секундах (по умолчанию: 30)
  --retries INTEGER      Количество повторных попыток (по умолчанию: 3)
  --verbose              Подробный вывод
  --quiet                Минимальный вывод
  --dry-run              Тестовый запуск без сохранения
  --full-scan            Полное сканирование (игнорировать дубликаты)
  --export FORMAT        Экспорт в формат: json, csv, xlsx
  --filter KEYWORDS      Дополнительные ключевые слова для фильтрации
  --help                 Показать справку
```

### Конфигурационный файл

```python
# config.py
GEEKJOB_CONFIG = {
    'database': {
        'path': 'geekjob_vacancies.db',
        'timeout': 30,
        'check_same_thread': False
    },
    'parsing': {
        'default_query': 'дизайнер',
        'default_pages': 10,
        'delay_between_requests': 1.0,
        'request_timeout': 30,
        'max_retries': 3,
        'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    },
    'filtering': {
        'design_keywords': [
            'дизайн', 'дизайнер', 'ui/ux', 'продуктовый дизайн',
            'веб-дизайн', 'графический дизайн', 'motion дизайн'
        ],
        'exclude_keywords': [
            'программист', 'разработчик', 'backend', 'frontend'
        ]
    },
    'logging': {
        'level': 'INFO',
        'file': 'geekjob_parser.log',
        'max_size': 10485760,  # 10MB
        'backup_count': 5
    }
}
```

### Программный API

```python
from geekjob_parser import GeekjobParser

# Создание парсера
parser = GeekjobParser(
    db_path='custom.db',
    delay=0.5,
    verbose=True
)

# Парсинг с настройками
results = parser.parse_vacancies(
    query='UI дизайнер',
    pages=5,
    full_scan=False
)

# Получение статистики
stats = parser.get_statistics()
print(f"Всего вакансий: {stats['total']}")
print(f"За последний день: {stats['last_24h']}")

# Экспорт данных
parser.export_to_json('vacancies.json')
parser.export_to_csv('vacancies.csv')
```

## 📊 Мониторинг и отладка

### Логирование

```bash
# Просмотр логов в реальном времени
tail -f geekjob_parser.log

# Поиск ошибок
grep "ERROR" geekjob_parser.log

# Статистика по логам
grep "✅ Сохранена вакансия" geekjob_parser.log | wc -l
```

### Мониторинг базы данных

```sql
-- Общая статистика
SELECT 
    COUNT(*) as total_vacancies,
    COUNT(DISTINCT company) as unique_companies,
    MAX(created_at) as last_update
FROM vacancies;

-- Статистика по дням
SELECT 
    DATE(created_at) as date,
    COUNT(*) as vacancies_count
FROM vacancies 
GROUP BY DATE(created_at) 
ORDER BY date DESC 
LIMIT 7;

-- Топ компаний
SELECT 
    company,
    COUNT(*) as vacancy_count
FROM vacancies 
GROUP BY company 
ORDER BY vacancy_count DESC 
LIMIT 10;

-- Проверка качества данных
SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN full_description IS NOT NULL AND full_description != '' THEN 1 ELSE 0 END) as with_description,
    SUM(CASE WHEN requirements IS NOT NULL AND requirements != '' THEN 1 ELSE 0 END) as with_requirements,
    SUM(CASE WHEN tasks IS NOT NULL AND tasks != '' THEN 1 ELSE 0 END) as with_tasks
FROM vacancies;
```

### Системный мониторинг

```bash
# Создание скрипта мониторинга
cat > monitor_parser.sh << 'EOF'
#!/bin/bash

LOG_FILE="geekjob_parser.log"
DB_FILE="geekjob_vacancies.db"

echo "=== Geekjob Parser Monitor ==="
echo "Время: $(date)"
echo

# Проверка файлов
if [ -f "$LOG_FILE" ]; then
    echo "📄 Размер лога: $(du -h $LOG_FILE | cut -f1)"
    echo "🕐 Последняя запись: $(tail -1 $LOG_FILE | cut -d' ' -f1-2)"
else
    echo "⚠️ Лог файл не найден"
fi

if [ -f "$DB_FILE" ]; then
    echo "💾 Размер БД: $(du -h $DB_FILE | cut -f1)"
    echo "📊 Всего вакансий: $(sqlite3 $DB_FILE 'SELECT COUNT(*) FROM vacancies')"
    echo "🆕 За последние 24ч: $(sqlite3 $DB_FILE "SELECT COUNT(*) FROM vacancies WHERE created_at > datetime('now', '-1 day')")"
else
    echo "⚠️ База данных не найдена"
fi

# Проверка процессов
if pgrep -f "geekjob_parser.py" > /dev/null; then
    echo "🟢 Парсер запущен"
else
    echo "🔴 Парсер не запущен"
fi

echo
echo "=== Последние ошибки ==="
if [ -f "$LOG_FILE" ]; then
    tail -100 "$LOG_FILE" | grep "ERROR" | tail -5
else
    echo "Нет данных"
fi
EOF

chmod +x monitor_parser.sh
```

### Веб-дашборд (опционально)

```python
# dashboard.py - простой веб-интерфейс для мониторинга
from flask import Flask, render_template, jsonify
import sqlite3
from datetime import datetime, timedelta

app = Flask(__name__)

@app.route('/')
def dashboard():
    return render_template('dashboard.html')

@app.route('/api/stats')
def get_stats():
    with sqlite3.connect('geekjob_vacancies.db') as conn:
        cursor = conn.cursor()
        
        # Общая статистика
        cursor.execute('SELECT COUNT(*) FROM vacancies')
        total = cursor.fetchone()[0]
        
        # За последние 24 часа
        cursor.execute("""
            SELECT COUNT(*) FROM vacancies 
            WHERE created_at > datetime('now', '-1 day')
        """)
        last_24h = cursor.fetchone()[0]
        
        # Топ компаний
        cursor.execute("""
            SELECT company, COUNT(*) as count 
            FROM vacancies 
            GROUP BY company 
            ORDER BY count DESC 
            LIMIT 5
        """)
        top_companies = cursor.fetchall()
        
        return jsonify({
            'total': total,
            'last_24h': last_24h,
            'top_companies': [{'name': c[0], 'count': c[1]} for c in top_companies]
        })

if __name__ == '__main__':
    app.run(debug=True, port=5001)
```

## ⚡ Производительность

### Оптимизация скорости

```python
# Многопоточный парсинг
python geekjob_parser.py --threads 4 --pages 20

# Увеличение batch size для БД
python geekjob_parser.py --batch-size 50

# Отключение подробного логирования
python geekjob_parser.py --quiet --pages 50
```

### Оптимизация ресурсов

```python
# Ограничение памяти
python geekjob_parser.py --max-memory 512MB

# Сжатие базы данных
sqlite3 geekjob_vacancies.db "VACUUM;"

# Очистка старых записей
sqlite3 geekjob_vacancies.db "DELETE FROM vacancies WHERE created_at < datetime('now', '-30 days');"
```

### Бенчмарки

| Параметр | Значение |
|----------|----------|
| Скорость парсинга | ~50-100 вакансий/мин |
| Потребление памяти | ~50-100 MB |
| Размер БД (1000 вакансий) | ~2-5 MB |
| Время отклика API | <2 сек |

## 🆘 Устранение неполадок

### Частые проблемы

**1. Ошибка подключения к сайту**
```bash
# Проверьте интернет-соединение
curl -I https://geekjob.ru

# Попробуйте с другим User-Agent
python geekjob_parser.py --user-agent "Custom Bot 1.0"
```

**2. База данных заблокирована**
```bash
# Проверьте процессы
lsof geekjob_vacancies.db

# Принудительное закрытие
pkill -f geekjob_parser.py
```

**3. Не находит вакансии**
```bash
# Тестовый запуск с отладкой
python geekjob_parser.py --dry-run --verbose --pages 1

# Проверьте селекторы
python test_selectors.py
```

### Диагностика

```bash
# Полная диагностика
python geekjob_parser.py --diagnose

# Проверка зависимостей
pip check

# Тест подключения
python -c "import requests; print(requests.get('https://geekjob.ru').status_code)"
```

## 📞 Поддержка

### Документация
- `README_GEEKJOB_PARSER.md` - подробная документация парсера
- `GEEKJOB_INTEGRATION.md` - руководство по интеграции с Next.js
- Комментарии в коде - объяснение сложных участков

### Логи и отладка
- `geekjob_parser.log` - основные логи парсера
- `test_results.log` - результаты тестирования
- `--verbose` флаг для подробного вывода

### Контакты
- GitHub Issues: для сообщений об ошибках
- Email: для технической поддержки
- Документация: встроенная справка `--help`

---

## 📈 Roadmap

### Версия 1.1 (планируется)
- [ ] Поддержка PostgreSQL
- [ ] Веб-интерфейс для настройки
- [ ] Интеграция с Telegram ботом
- [ ] Экспорт в Excel с форматированием

### Версия 1.2 (планируется)
- [ ] Машинное обучение для классификации вакансий
- [ ] API для внешних интеграций
- [ ] Поддержка прокси-серверов
- [ ] Распределённый парсинг

---

**Версия**: 1.0  
**Дата**: 2025-01-02  
**Автор**: AI Assistant  
**Лицензия**: MIT  

Создано специально для эффективного парсинга дизайнерских вакансий с Geekjob.ru 🎨
