#!/usr/bin/env python3
"""
Создание релизного пакета Geekjob Parser

Этот скрипт собирает все файлы парсера в архив для распространения.
"""

import os
import sys
import shutil
import zipfile
import tarfile
from datetime import datetime
from pathlib import Path


def create_release_package():
    """Создание релизного пакета"""
    
    # Информация о релизе
    version = "1.0.0"
    release_date = datetime.now().strftime("%Y-%m-%d")
    package_name = f"geekjob-parser-v{version}-{release_date}"
    
    print(f"📦 Создание релизного пакета: {package_name}")
    print("=" * 60)
    
    # Список файлов для включения в пакет
    files_to_include = [
        # Основные файлы парсера
        "geekjob_parser.py",
        "requirements.txt",
        "setup_parser.py",
        
        # Тестирование
        "test_geekjob_parser.py",
        
        # Интеграция
        "integrate_with_nextjs.py",
        
        # Демонстрация
        "demo_all_features.py",
        
        # Документация
        "README_GEEKJOB_PARSER.md",
        "README_FINAL.md",
        
        # Этот скрипт
        "create_release_package.py"
    ]
    
    # Проверяем наличие файлов
    missing_files = []
    existing_files = []
    
    for filename in files_to_include:
        if os.path.exists(filename):
            size = os.path.getsize(filename)
            existing_files.append((filename, size))
            print(f"✅ {filename} ({size:,} байт)")
        else:
            missing_files.append(filename)
            print(f"❌ {filename} - НЕ НАЙДЕН")
    
    if missing_files:
        print(f"\n⚠️ Отсутствуют файлы: {', '.join(missing_files)}")
        print("Создание пакета будет продолжено без этих файлов")
    
    # Создаём временную директорию для пакета
    temp_dir = Path(package_name)
    if temp_dir.exists():
        shutil.rmtree(temp_dir)
    
    temp_dir.mkdir()
    print(f"\n📁 Создана временная директория: {temp_dir}")
    
    # Копируем файлы
    total_size = 0
    copied_files = []
    
    for filename, size in existing_files:
        try:
            dest_path = temp_dir / filename
            shutil.copy2(filename, dest_path)
            copied_files.append(filename)
            total_size += size
            print(f"📄 Скопирован: {filename}")
        except Exception as e:
            print(f"❌ Ошибка копирования {filename}: {e}")
    
    # Создаём файл с информацией о релизе
    release_info = f"""# Geekjob Parser v{version}

**Дата релиза**: {release_date}
**Версия**: {version}
**Автор**: AI Assistant

## 📋 Содержимое пакета

### Основные файлы
- `geekjob_parser.py` - Основной парсер
- `requirements.txt` - Зависимости Python
- `setup_parser.py` - Скрипт настройки

### Тестирование
- `test_geekjob_parser.py` - Автоматические тесты

### Интеграция
- `integrate_with_nextjs.py` - Автоматическая интеграция с Next.js

### Демонстрация
- `demo_all_features.py` - Демонстрация всех возможностей

### Документация
- `README_GEEKJOB_PARSER.md` - Подробная документация парсера
- `README_FINAL.md` - Полное руководство пользователя

## 🚀 Быстрый старт

1. Установите зависимости:
   ```bash
   pip install -r requirements.txt
   ```

2. Настройте парсер:
   ```bash
   python setup_parser.py
   ```

3. Запустите парсер:
   ```bash
   python geekjob_parser.py
   ```

4. Для интеграции с Next.js:
   ```bash
   python integrate_with_nextjs.py
   ```

5. Для демонстрации всех возможностей:
   ```bash
   python demo_all_features.py
   ```

## 📚 Документация

Полная документация находится в файлах:
- `README_FINAL.md` - Основное руководство
- `README_GEEKJOB_PARSER.md` - Техническая документация

## 🆘 Поддержка

При возникновении проблем:
1. Проверьте логи в `geekjob_parser.log`
2. Запустите тесты: `python test_geekjob_parser.py`
3. Изучите документацию

---
Создано автоматически {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
"""
    
    release_info_path = temp_dir / "RELEASE_INFO.md"
    with open(release_info_path, 'w', encoding='utf-8') as f:
        f.write(release_info)
    
    print(f"📄 Создан файл с информацией о релизе: RELEASE_INFO.md")
    
    # Создаём архивы
    archives_created = []
    
    # ZIP архив
    try:
        zip_filename = f"{package_name}.zip"
        with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(temp_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arc_name = os.path.relpath(file_path, temp_dir)
                    zipf.write(file_path, arc_name)
        
        zip_size = os.path.getsize(zip_filename)
        archives_created.append((zip_filename, zip_size))
        print(f"📦 Создан ZIP архив: {zip_filename} ({zip_size:,} байт)")
        
    except Exception as e:
        print(f"❌ Ошибка создания ZIP архива: {e}")
    
    # TAR.GZ архив
    try:
        tar_filename = f"{package_name}.tar.gz"
        with tarfile.open(tar_filename, 'w:gz') as tarf:
            for root, dirs, files in os.walk(temp_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arc_name = os.path.relpath(file_path, temp_dir)
                    tarf.add(file_path, arcname=arc_name)
        
        tar_size = os.path.getsize(tar_filename)
        archives_created.append((tar_filename, tar_size))
        print(f"📦 Создан TAR.GZ архив: {tar_filename} ({tar_size:,} байт)")
        
    except Exception as e:
        print(f"❌ Ошибка создания TAR.GZ архива: {e}")
    
    # Удаляем временную директорию
    try:
        shutil.rmtree(temp_dir)
        print(f"🧹 Удалена временная директория: {temp_dir}")
    except Exception as e:
        print(f"⚠️ Не удалось удалить временную директорию: {e}")
    
    # Итоговый отчёт
    print("\n" + "=" * 60)
    print("🎉 РЕЛИЗНЫЙ ПАКЕТ СОЗДАН УСПЕШНО!")
    print("=" * 60)
    
    print(f"📊 Статистика:")
    print(f"   Версия: {version}")
    print(f"   Дата: {release_date}")
    print(f"   Файлов включено: {len(copied_files)}")
    print(f"   Общий размер: {total_size:,} байт ({total_size/1024/1024:.2f} MB)")
    
    if archives_created:
        print(f"\n📦 Созданные архивы:")
        for archive_name, archive_size in archives_created:
            compression_ratio = (1 - archive_size / total_size) * 100
            print(f"   {archive_name}: {archive_size:,} байт (сжатие {compression_ratio:.1f}%)")
    
    print(f"\n📋 Включённые файлы:")
    for filename in copied_files:
        print(f"   ✅ {filename}")
    
    if missing_files:
        print(f"\n⚠️ Пропущенные файлы:")
        for filename in missing_files:
            print(f"   ❌ {filename}")
    
    print(f"\n🚀 Инструкции по использованию:")
    print(f"   1. Распакуйте архив:")
    if archives_created:
        archive_name = archives_created[0][0]
        if archive_name.endswith('.zip'):
            print(f"      unzip {archive_name}")
        else:
            print(f"      tar -xzf {archive_name}")
    
    print(f"   2. Перейдите в директорию:")
    print(f"      cd {package_name}")
    
    print(f"   3. Установите зависимости:")
    print(f"      pip install -r requirements.txt")
    
    print(f"   4. Запустите настройку:")
    print(f"      python setup_parser.py")
    
    print(f"   5. Начните парсинг:")
    print(f"      python geekjob_parser.py")
    
    print(f"\n📚 Документация:")
    print(f"   README_FINAL.md - Полное руководство")
    print(f"   README_GEEKJOB_PARSER.md - Техническая документация")
    print(f"   RELEASE_INFO.md - Информация о релизе")
    
    print(f"\n🔗 Интеграция с Next.js:")
    print(f"   python integrate_with_nextjs.py")
    
    print(f"\n🎯 Демонстрация:")
    print(f"   python demo_all_features.py")
    
    return len(archives_created) > 0


def main():
    """Главная функция"""
    print("📦 Geekjob Parser - Создание релизного пакета")
    print("Версия: 1.0.0")
    print("Дата: 2025-01-02")
    print()
    
    try:
        success = create_release_package()
        return 0 if success else 1
        
    except KeyboardInterrupt:
        print("\n\n⚠️ Создание пакета прервано пользователем")
        return 1
    except Exception as e:
        print(f"\n\n❌ Ошибка при создании пакета: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
