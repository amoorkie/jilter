#!/usr/bin/env python3
"""
Демонстрация всех возможностей Geekjob Parser

Этот скрипт показывает все функции парсера:
- Базовый парсинг
- Экспорт в разные форматы
- Статистика и аналитика
- Интеграция с Next.js
- Мониторинг и отладка
"""

import os
import sys
import time
import json
import sqlite3
import subprocess
from pathlib import Path
from datetime import datetime, timedelta


def print_header(title):
    """Красивый заголовок"""
    print("\n" + "=" * 60)
    print(f"🎯 {title}")
    print("=" * 60)


def print_step(step, description):
    """Шаг демонстрации"""
    print(f"\n📋 Шаг {step}: {description}")
    print("-" * 40)


def run_command(cmd, description=""):
    """Выполнение команды с выводом"""
    if description:
        print(f"🚀 {description}")
    
    print(f"💻 Команда: {cmd}")
    
    try:
        result = subprocess.run(
            cmd, 
            shell=True, 
            capture_output=True, 
            text=True,
            timeout=60
        )
        
        if result.stdout:
            print("✅ Вывод:")
            print(result.stdout)
        
        if result.stderr:
            print("⚠️ Предупреждения:")
            print(result.stderr)
        
        return result.returncode == 0
        
    except subprocess.TimeoutExpired:
        print("⏰ Команда превысила лимит времени (60 сек)")
        return False
    except Exception as e:
        print(f"❌ Ошибка выполнения: {e}")
        return False


def check_database_stats(db_path="geekjob_vacancies.db"):
    """Проверка статистики базы данных"""
    if not os.path.exists(db_path):
        print(f"⚠️ База данных {db_path} не найдена")
        return
    
    try:
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            
            # Общая статистика
            cursor.execute('SELECT COUNT(*) FROM vacancies')
            total = cursor.fetchone()[0]
            
            # За последние 24 часа
            cursor.execute("""
                SELECT COUNT(*) FROM vacancies 
                WHERE created_at > datetime('now', '-1 day')
            """)
            recent = cursor.fetchone()[0]
            
            # Уникальные компании
            cursor.execute('SELECT COUNT(DISTINCT company) FROM vacancies')
            companies = cursor.fetchone()[0]
            
            # Качество данных
            cursor.execute("""
                SELECT 
                    SUM(CASE WHEN full_description IS NOT NULL AND full_description != '' THEN 1 ELSE 0 END) as with_desc,
                    SUM(CASE WHEN requirements IS NOT NULL AND requirements != '' THEN 1 ELSE 0 END) as with_req,
                    SUM(CASE WHEN tasks IS NOT NULL AND tasks != '' THEN 1 ELSE 0 END) as with_tasks
                FROM vacancies
            """)
            quality = cursor.fetchone()
            
            print(f"📊 Статистика базы данных:")
            print(f"   Всего вакансий: {total}")
            print(f"   За последние 24ч: {recent}")
            print(f"   Уникальных компаний: {companies}")
            print(f"   С полным описанием: {quality[0]}/{total} ({quality[0]/total*100:.1f}%)" if total > 0 else "   С полным описанием: 0%")
            print(f"   С требованиями: {quality[1]}/{total} ({quality[1]/total*100:.1f}%)" if total > 0 else "   С требованиями: 0%")
            print(f"   С задачами: {quality[2]}/{total} ({quality[2]/total*100:.1f}%)" if total > 0 else "   С задачами: 0%")
            
            # Топ компаний
            cursor.execute("""
                SELECT company, COUNT(*) as count 
                FROM vacancies 
                GROUP BY company 
                ORDER BY count DESC 
                LIMIT 5
            """)
            top_companies = cursor.fetchall()
            
            if top_companies:
                print(f"\n🏢 Топ-5 компаний:")
                for i, (company, count) in enumerate(top_companies, 1):
                    print(f"   {i}. {company}: {count} вакансий")
            
    except sqlite3.Error as e:
        print(f"❌ Ошибка работы с базой данных: {e}")


def demo_basic_parsing():
    """Демонстрация базового парсинга"""
    print_step(1, "Базовый парсинг вакансий")
    
    # Проверяем наличие парсера
    if not os.path.exists('geekjob_parser.py'):
        print("❌ Файл geekjob_parser.py не найден")
        print("Убедитесь, что все файлы парсера находятся в текущей директории")
        return False
    
    # Быстрый тест (1 страница)
    success = run_command(
        'python geekjob_parser.py --pages 1 --verbose',
        "Тестовый парсинг (1 страница)"
    )
    
    if success:
        check_database_stats()
        return True
    else:
        print("❌ Тестовый парсинг не удался")
        return False


def demo_advanced_parsing():
    """Демонстрация продвинутого парсинга"""
    print_step(2, "Продвинутый парсинг с настройками")
    
    # Парсинг с кастомными параметрами
    success = run_command(
        'python geekjob_parser.py --query "UI дизайнер" --pages 3 --delay 0.5 --verbose',
        "Парсинг UI дизайнеров (3 страницы, быстрый режим)"
    )
    
    if success:
        check_database_stats()
        return True
    else:
        print("❌ Продвинутый парсинг не удался")
        return False


def demo_export_features():
    """Демонстрация экспорта данных"""
    print_step(3, "Экспорт данных в разные форматы")
    
    # Проверяем наличие данных
    if not os.path.exists('geekjob_vacancies.db'):
        print("⚠️ База данных не найдена, пропускаем экспорт")
        return False
    
    # Экспорт в JSON
    success1 = run_command(
        'python geekjob_parser.py --export json',
        "Экспорт в JSON формат"
    )
    
    # Экспорт в CSV
    success2 = run_command(
        'python geekjob_parser.py --export csv',
        "Экспорт в CSV формат"
    )
    
    # Проверяем созданные файлы
    files_created = []
    for filename in ['geekjob_vacancies.json', 'geekjob_vacancies.csv']:
        if os.path.exists(filename):
            size = os.path.getsize(filename)
            files_created.append(f"{filename} ({size} байт)")
    
    if files_created:
        print("✅ Созданы файлы:")
        for file_info in files_created:
            print(f"   📄 {file_info}")
    
    return success1 or success2


def demo_testing():
    """Демонстрация тестирования"""
    print_step(4, "Тестирование парсера")
    
    if not os.path.exists('test_geekjob_parser.py'):
        print("⚠️ Файл test_geekjob_parser.py не найден, пропускаем тесты")
        return False
    
    success = run_command(
        'python test_geekjob_parser.py',
        "Запуск автоматических тестов"
    )
    
    return success


def demo_integration():
    """Демонстрация интеграции с Next.js"""
    print_step(5, "Интеграция с Next.js проектом")
    
    if not os.path.exists('integrate_with_nextjs.py'):
        print("⚠️ Файл integrate_with_nextjs.py не найден")
        return False
    
    # Ищем Next.js проект
    nextjs_dirs = []
    for item in os.listdir('.'):
        if os.path.isdir(item):
            package_json = os.path.join(item, 'package.json')
            if os.path.exists(package_json):
                try:
                    with open(package_json, 'r') as f:
                        data = json.load(f)
                        if 'next' in data.get('dependencies', {}) or 'next' in data.get('devDependencies', {}):
                            nextjs_dirs.append(item)
                except:
                    pass
    
    if nextjs_dirs:
        print(f"✅ Найдены Next.js проекты: {', '.join(nextjs_dirs)}")
        print("🔗 Для интеграции запустите:")
        print("   python integrate_with_nextjs.py")
    else:
        print("⚠️ Next.js проекты не найдены в текущей директории")
        print("💡 Создайте тестовый Next.js проект:")
        print("   npx create-next-app@latest test-project")
        print("   cd test-project")
        print("   python ../integrate_with_nextjs.py")
    
    return True


def demo_monitoring():
    """Демонстрация мониторинга"""
    print_step(6, "Мониторинг и статистика")
    
    # Проверяем логи
    log_files = ['geekjob_parser.log', 'test_results.log']
    for log_file in log_files:
        if os.path.exists(log_file):
            size = os.path.getsize(log_file)
            print(f"📄 {log_file}: {size} байт")
            
            # Показываем последние записи
            try:
                with open(log_file, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    if lines:
                        print(f"   Последняя запись: {lines[-1].strip()}")
            except:
                pass
        else:
            print(f"⚠️ {log_file} не найден")
    
    # Статистика базы данных
    check_database_stats()
    
    return True


def demo_performance():
    """Демонстрация производительности"""
    print_step(7, "Тест производительности")
    
    print("⏱️ Измеряем скорость парсинга...")
    
    start_time = time.time()
    
    # Быстрый парсинг для теста производительности
    success = run_command(
        'python geekjob_parser.py --pages 2 --delay 0.3 --quiet',
        "Быстрый парсинг для теста производительности"
    )
    
    end_time = time.time()
    duration = end_time - start_time
    
    if success:
        print(f"⚡ Время выполнения: {duration:.2f} секунд")
        print(f"📊 Примерная скорость: ~{60/duration:.1f} вакансий/мин")
    
    return success


def demo_cleanup():
    """Демонстрация очистки"""
    print_step(8, "Очистка и обслуживание")
    
    # Показываем размеры файлов
    files_to_check = [
        'geekjob_vacancies.db',
        'geekjob_parser.log',
        'geekjob_vacancies.json',
        'geekjob_vacancies.csv'
    ]
    
    total_size = 0
    for filename in files_to_check:
        if os.path.exists(filename):
            size = os.path.getsize(filename)
            total_size += size
            print(f"📄 {filename}: {size:,} байт")
    
    print(f"💾 Общий размер файлов: {total_size:,} байт ({total_size/1024/1024:.2f} MB)")
    
    # Предлагаем очистку
    print("\n🧹 Для очистки тестовых данных выполните:")
    print("   rm -f geekjob_vacancies.db geekjob_parser.log")
    print("   rm -f geekjob_vacancies.json geekjob_vacancies.csv")
    
    return True


def main():
    """Главная функция демонстрации"""
    print_header("Демонстрация Geekjob Parser v1.0")
    
    print("🎯 Этот скрипт продемонстрирует все возможности парсера:")
    print("   1. Базовый парсинг вакансий")
    print("   2. Продвинутые настройки")
    print("   3. Экспорт данных")
    print("   4. Автоматическое тестирование")
    print("   5. Интеграция с Next.js")
    print("   6. Мониторинг и статистика")
    print("   7. Тест производительности")
    print("   8. Очистка и обслуживание")
    
    print(f"\n📅 Дата: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"📁 Рабочая директория: {os.getcwd()}")
    print(f"🐍 Python версия: {sys.version}")
    
    # Проверяем зависимости
    print("\n🔍 Проверка зависимостей...")
    required_modules = ['requests', 'beautifulsoup4', 'lxml']
    missing_modules = []
    
    for module in required_modules:
        try:
            __import__(module.replace('-', '_'))
            print(f"   ✅ {module}")
        except ImportError:
            missing_modules.append(module)
            print(f"   ❌ {module}")
    
    if missing_modules:
        print(f"\n⚠️ Отсутствуют модули: {', '.join(missing_modules)}")
        print("Установите их командой:")
        print(f"   pip install {' '.join(missing_modules)}")
        return 1
    
    # Запрашиваем подтверждение
    print("\n" + "=" * 60)
    response = input("🚀 Начать демонстрацию? (y/N): ").lower()
    if response not in ['y', 'yes', 'да']:
        print("❌ Демонстрация отменена")
        return 0
    
    # Выполняем демонстрацию
    results = {}
    
    try:
        results['basic_parsing'] = demo_basic_parsing()
        time.sleep(2)
        
        results['advanced_parsing'] = demo_advanced_parsing()
        time.sleep(2)
        
        results['export'] = demo_export_features()
        time.sleep(1)
        
        results['testing'] = demo_testing()
        time.sleep(1)
        
        results['integration'] = demo_integration()
        time.sleep(1)
        
        results['monitoring'] = demo_monitoring()
        time.sleep(1)
        
        results['performance'] = demo_performance()
        time.sleep(1)
        
        results['cleanup'] = demo_cleanup()
        
    except KeyboardInterrupt:
        print("\n\n⚠️ Демонстрация прервана пользователем")
        return 1
    except Exception as e:
        print(f"\n\n❌ Ошибка во время демонстрации: {e}")
        return 1
    
    # Итоговый отчёт
    print_header("Итоговый отчёт")
    
    successful_steps = sum(1 for success in results.values() if success)
    total_steps = len(results)
    
    print(f"📊 Результаты демонстрации:")
    print(f"   Успешных шагов: {successful_steps}/{total_steps}")
    print(f"   Процент успеха: {successful_steps/total_steps*100:.1f}%")
    
    print(f"\n📋 Детальные результаты:")
    step_names = {
        'basic_parsing': 'Базовый парсинг',
        'advanced_parsing': 'Продвинутый парсинг',
        'export': 'Экспорт данных',
        'testing': 'Тестирование',
        'integration': 'Интеграция с Next.js',
        'monitoring': 'Мониторинг',
        'performance': 'Тест производительности',
        'cleanup': 'Очистка'
    }
    
    for step, success in results.items():
        status = "✅ Успешно" if success else "❌ Ошибка"
        name = step_names.get(step, step)
        print(f"   {name}: {status}")
    
    if successful_steps == total_steps:
        print(f"\n🎉 Демонстрация завершена успешно!")
        print(f"🚀 Geekjob Parser готов к использованию!")
    else:
        print(f"\n⚠️ Демонстрация завершена с ошибками")
        print(f"📚 Проверьте документацию и логи для устранения проблем")
    
    print(f"\n📚 Документация:")
    print(f"   README_FINAL.md - полное руководство")
    print(f"   README_GEEKJOB_PARSER.md - документация парсера")
    print(f"   geekjob_parser.py --help - справка по командам")
    
    print(f"\n🔗 Следующие шаги:")
    print(f"   1. Настройте автоматический запуск (cron/systemd)")
    print(f"   2. Интегрируйте с вашим Next.js проектом")
    print(f"   3. Настройте мониторинг и алерты")
    print(f"   4. Оптимизируйте параметры под ваши нужды")
    
    return 0 if successful_steps == total_steps else 1


if __name__ == "__main__":
    sys.exit(main())
