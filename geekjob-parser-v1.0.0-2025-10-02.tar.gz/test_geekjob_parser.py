#!/usr/bin/env python3
"""
Тестовый скрипт для Geekjob Parser

Проверяет основные функции парсера без сохранения в базу данных.
Полезен для отладки и проверки работоспособности.
"""

import sys
import tempfile
import os

# Добавляем текущую директорию в путь для импорта
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from geekjob_parser import GeekjobParser


def test_parser():
    """Тестирование основных функций парсера"""
    print("🧪 Запуск тестов Geekjob Parser")
    print("=" * 50)
    
    # Создаём временную базу данных
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
        db_path = tmp_db.name
    
    try:
        # Инициализация парсера
        print("1. Инициализация парсера...")
        parser = GeekjobParser(
            db_path=db_path,
            query="дизайнер",
            delay=0.5  # Уменьшенная задержка для тестов
        )
        print("✅ Парсер инициализирован успешно")
        
        # Тест получения URL вакансий
        print("\n2. Тест получения URL вакансий...")
        vacancy_urls = parser.get_vacancy_urls(max_pages=1)  # Только первая страница
        print(f"✅ Найдено {len(vacancy_urls)} URL вакансий")
        
        if vacancy_urls:
            print("Примеры URL:")
            for i, url in enumerate(vacancy_urls[:3], 1):
                print(f"   {i}. {url}")
        
        # Тест парсинга одной вакансии
        if vacancy_urls:
            print("\n3. Тест парсинга детальной информации...")
            test_url = vacancy_urls[0]
            print(f"Тестируем URL: {test_url}")
            
            vacancy_data = parser.parse_vacancy_details(test_url)
            
            if vacancy_data:
                print("✅ Парсинг успешен!")
                print("Извлечённые данные:")
                print(f"   Заголовок: {vacancy_data['title']}")
                print(f"   Компания: {vacancy_data['company']}")
                print(f"   Локация: {vacancy_data['location']}")
                print(f"   Зарплата: {vacancy_data['salary_min']}-{vacancy_data['salary_max']} {vacancy_data['salary_currency']}")
                print(f"   Описание: {vacancy_data['description'][:100]}...")
                print(f"   Полное описание: {len(vacancy_data['full_description'])} символов")
                print(f"   Требования: {len(vacancy_data['requirements'])} символов")
                print(f"   Задачи: {len(vacancy_data['tasks'])} символов")
                print(f"   Условия: {len(vacancy_data['conditions'])} символов")
                print(f"   Льготы: {len(vacancy_data['benefits'])} символов")
                
                # Тест сохранения в базу
                print("\n4. Тест сохранения в базу данных...")
                if parser.save_vacancy(vacancy_data):
                    print("✅ Сохранение в базу успешно")
                else:
                    print("❌ Ошибка сохранения в базу")
            else:
                print("❌ Ошибка парсинга вакансии")
        
        # Тест парсинга зарплаты
        print("\n5. Тест парсинга зарплаты...")
        test_salaries = [
            "от 100 000 ₽",
            "150 000 - 200 000 руб",
            "$2000-$3000",
            "до 180000 рублей",
            "200к ₽",
            "не указана"
        ]
        
        for salary_text in test_salaries:
            min_sal, max_sal, currency = parser.parse_salary(salary_text)
            print(f"   '{salary_text}' -> {min_sal}-{max_sal} {currency}")
        
        print("\n✅ Все тесты завершены успешно!")
        
    except Exception as e:
        print(f"❌ Ошибка в тестах: {e}")
        return False
    
    finally:
        # Удаляем временную базу данных
        try:
            os.unlink(db_path)
        except:
            pass
    
    return True


def test_database_integration():
    """Тест интеграции с существующей базой данных"""
    print("\n🔗 Тест интеграции с базой данных")
    print("=" * 50)
    
    # Ищем существующую базу данных
    possible_db_paths = [
        'database.db',
        'src/database.db',
        '../database.db',
        './job-filter-mvp/database.db'
    ]
    
    db_path = None
    for path in possible_db_paths:
        if os.path.exists(path):
            db_path = path
            break
    
    if not db_path:
        print("⚠️ Существующая база данных не найдена")
        print("Создаём тестовую базу...")
        db_path = 'test_database.db'
    
    try:
        parser = GeekjobParser(db_path=db_path, query="тест")
        print(f"✅ Подключение к базе {db_path} успешно")
        
        # Проверяем структуру таблицы
        import sqlite3
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("PRAGMA table_info(vacancies)")
            columns = cursor.fetchall()
            
            print(f"Найдено {len(columns)} колонок в таблице vacancies:")
            for col in columns[:5]:  # Показываем первые 5 колонок
                print(f"   - {col[1]} ({col[2]})")
            if len(columns) > 5:
                print(f"   ... и ещё {len(columns) - 5} колонок")
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка интеграции с базой: {e}")
        return False
    
    finally:
        # Удаляем тестовую базу если создавали
        if db_path == 'test_database.db' and os.path.exists(db_path):
            try:
                os.unlink(db_path)
            except:
                pass


def main():
    """Главная функция тестирования"""
    print("🚀 Тестирование Geekjob Parser")
    print("Версия: 1.0")
    print("Дата: 2025-01-02")
    print()
    
    success = True
    
    # Основные тесты
    if not test_parser():
        success = False
    
    # Тест интеграции с базой
    if not test_database_integration():
        success = False
    
    print("\n" + "=" * 50)
    if success:
        print("🎉 Все тесты пройдены успешно!")
        print("Парсер готов к использованию.")
    else:
        print("❌ Некоторые тесты не пройдены.")
        print("Проверьте логи и исправьте ошибки.")
    
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
