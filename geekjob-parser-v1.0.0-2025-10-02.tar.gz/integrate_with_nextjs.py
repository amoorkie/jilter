#!/usr/bin/env python3
"""
Скрипт интеграции Geekjob Parser с Next.js проектом

Автоматически находит Next.js проект, копирует парсер,
настраивает интеграцию с существующей базой данных.
"""

import os
import sys
import shutil
import json
import sqlite3
from pathlib import Path


def find_nextjs_project():
    """Поиск Next.js проекта в текущей директории и родительских"""
    current_dir = Path.cwd()
    
    # Проверяем текущую директорию и родительские
    for path in [current_dir] + list(current_dir.parents):
        package_json = path / 'package.json'
        
        if package_json.exists():
            try:
                with open(package_json, 'r', encoding='utf-8') as f:
                    package_data = json.load(f)
                
                # Проверяем наличие Next.js в зависимостях
                dependencies = package_data.get('dependencies', {})
                dev_dependencies = package_data.get('devDependencies', {})
                
                if 'next' in dependencies or 'next' in dev_dependencies:
                    print(f"✅ Найден Next.js проект: {path}")
                    return path
                    
            except (json.JSONDecodeError, FileNotFoundError):
                continue
    
    return None


def find_database_file(project_path):
    """Поиск файла базы данных в Next.js проекте"""
    possible_paths = [
        project_path / 'database.db',
        project_path / 'src' / 'database.db',
        project_path / 'lib' / 'database.db',
        project_path / 'data' / 'database.db'
    ]
    
    for db_path in possible_paths:
        if db_path.exists():
            print(f"✅ Найдена база данных: {db_path}")
            return db_path
    
    print("⚠️ База данных не найдена, будет создана новая")
    return project_path / 'database.db'


def check_database_schema(db_path):
    """Проверка схемы базы данных"""
    try:
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            
            # Проверяем существование таблицы vacancies
            cursor.execute("""
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name='vacancies'
            """)
            
            if not cursor.fetchone():
                print("⚠️ Таблица vacancies не найдена")
                return False
            
            # Проверяем структуру таблицы
            cursor.execute("PRAGMA table_info(vacancies)")
            columns = cursor.fetchall()
            column_names = [col[1] for col in columns]
            
            required_columns = [
                'external_id', 'source', 'url', 'title', 'company',
                'full_description', 'requirements', 'tasks', 'benefits', 'conditions'
            ]
            
            missing_columns = [col for col in required_columns if col not in column_names]
            
            if missing_columns:
                print(f"⚠️ Отсутствуют колонки: {', '.join(missing_columns)}")
                return False
            
            print("✅ Схема базы данных совместима")
            return True
            
    except sqlite3.Error as e:
        print(f"❌ Ошибка проверки базы данных: {e}")
        return False


def copy_parser_files(project_path):
    """Копирование файлов парсера в проект"""
    files_to_copy = [
        'geekjob_parser.py',
        'requirements.txt',
        'test_geekjob_parser.py',
        'setup_parser.py',
        'README_GEEKJOB_PARSER.md'
    ]
    
    parsers_dir = project_path / 'parsers'
    parsers_dir.mkdir(exist_ok=True)
    
    copied_files = []
    
    for filename in files_to_copy:
        if os.path.exists(filename):
            try:
                dest_path = parsers_dir / filename
                shutil.copy2(filename, dest_path)
                copied_files.append(filename)
                print(f"✅ Скопирован: {filename}")
            except Exception as e:
                print(f"❌ Ошибка копирования {filename}: {e}")
        else:
            print(f"⚠️ Файл не найден: {filename}")
    
    return copied_files


def create_integration_script(project_path, db_path):
    """Создание скрипта интеграции"""
    script_content = f'''#!/usr/bin/env python3
"""
Скрипт запуска Geekjob Parser для проекта {project_path.name}

Автоматически сгенерирован integrate_with_nextjs.py
"""

import os
import sys
import subprocess
from pathlib import Path

# Настройки проекта
PROJECT_PATH = Path("{project_path}")
DATABASE_PATH = Path("{db_path}")
PARSER_PATH = PROJECT_PATH / "parsers" / "geekjob_parser.py"

def run_parser(query="дизайнер", pages=10, delay=1.0, verbose=False):
    """Запуск парсера с заданными параметрами"""
    
    if not PARSER_PATH.exists():
        print(f"❌ Парсер не найден: {{PARSER_PATH}}")
        return False
    
    cmd = [
        sys.executable,
        str(PARSER_PATH),
        "--db", str(DATABASE_PATH),
        "--query", query,
        "--pages", str(pages),
        "--delay", str(delay)
    ]
    
    if verbose:
        cmd.append("--verbose")
    
    print(f"🚀 Запуск парсера...")
    print(f"   База данных: {{DATABASE_PATH}}")
    print(f"   Запрос: {{query}}")
    print(f"   Страниц: {{pages}}")
    print(f"   Задержка: {{delay}}с")
    print()
    
    try:
        result = subprocess.run(cmd, cwd=PROJECT_PATH)
        return result.returncode == 0
    except Exception as e:
        print(f"❌ Ошибка запуска парсера: {{e}}")
        return False

def main():
    """Главная функция"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Запуск Geekjob Parser для проекта {project_path.name}")
    parser.add_argument("--query", "-q", default="дизайнер", help="Поисковый запрос")
    parser.add_argument("--pages", "-p", type=int, default=10, help="Количество страниц")
    parser.add_argument("--delay", "-d", type=float, default=1.0, help="Задержка между запросами")
    parser.add_argument("--verbose", "-v", action="store_true", help="Подробный вывод")
    
    args = parser.parse_args()
    
    success = run_parser(
        query=args.query,
        pages=args.pages,
        delay=args.delay,
        verbose=args.verbose
    )
    
    if success:
        print("✅ Парсинг завершён успешно!")
        print("Проверьте результаты в админ-панели Next.js")
    else:
        print("❌ Парсинг завершён с ошибками")
        print("Проверьте логи в parsers/geekjob_parser.log")
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
'''
    
    script_path = project_path / 'run_geekjob_parser.py'
    
    try:
        with open(script_path, 'w', encoding='utf-8') as f:
            f.write(script_content)
        
        # Делаем скрипт исполняемым на Unix системах
        if os.name != 'nt':
            os.chmod(script_path, 0o755)
        
        print(f"✅ Создан скрипт интеграции: {script_path}")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка создания скрипта интеграции: {e}")
        return False


def create_package_json_script(project_path):
    """Добавление скрипта в package.json"""
    package_json_path = project_path / 'package.json'
    
    if not package_json_path.exists():
        print("⚠️ package.json не найден")
        return False
    
    try:
        with open(package_json_path, 'r', encoding='utf-8') as f:
            package_data = json.load(f)
        
        # Добавляем скрипт парсинга
        if 'scripts' not in package_data:
            package_data['scripts'] = {}
        
        package_data['scripts']['parse-geekjob'] = 'python run_geekjob_parser.py'
        package_data['scripts']['parse-geekjob-verbose'] = 'python run_geekjob_parser.py --verbose'
        
        # Создаём резервную копию
        backup_path = package_json_path.with_suffix('.json.backup')
        shutil.copy2(package_json_path, backup_path)
        
        # Сохраняем обновлённый package.json
        with open(package_json_path, 'w', encoding='utf-8') as f:
            json.dump(package_data, f, indent=2, ensure_ascii=False)
        
        print("✅ Добавлены npm скрипты:")
        print("   npm run parse-geekjob")
        print("   npm run parse-geekjob-verbose")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка обновления package.json: {e}")
        return False


def create_readme_integration(project_path):
    """Создание документации по интеграции"""
    readme_content = f"""# Интеграция Geekjob Parser

Парсер Geekjob.ru успешно интегрирован в проект {project_path.name}.

## 🚀 Быстрый старт

### Запуск через Python
```bash
# Базовый запуск
python run_geekjob_parser.py

# С настройками
python run_geekjob_parser.py --query "python разработчик" --pages 5 --verbose
```

### Запуск через npm
```bash
# Базовый запуск
npm run parse-geekjob

# С подробными логами
npm run parse-geekjob-verbose
```

## 📁 Структура файлов

```
{project_path.name}/
├── parsers/                    # Папка с парсером
│   ├── geekjob_parser.py      # Основной парсер
│   ├── requirements.txt       # Зависимости Python
│   ├── test_geekjob_parser.py # Тесты
│   └── README_GEEKJOB_PARSER.md # Документация
├── run_geekjob_parser.py      # Скрипт запуска
├── database.db               # База данных SQLite
└── package.json              # Обновлён с npm скриптами
```

## ⚙️ Настройка автоматического запуска

### Cron (Linux/Mac)
```bash
# Каждые 4 часа
0 */4 * * * cd {project_path} && python run_geekjob_parser.py >> cron.log 2>&1
```

### Task Scheduler (Windows)
1. Откройте Task Scheduler
2. Создайте задачу
3. Программа: `python.exe`
4. Аргументы: `{project_path}/run_geekjob_parser.py`

## 🔍 Мониторинг

- **Логи парсера**: `parsers/geekjob_parser.log`
- **Логи cron**: `cron.log`
- **Админ-панель**: http://localhost:3000/admin

## 📊 Проверка результатов

После запуска парсера:

1. Запустите Next.js: `npm run dev`
2. Откройте админ-панель: http://localhost:3000/admin
3. Проверьте новые вакансии с source='geekjob'

## 🛠 Отладка

```bash
# Проверка подключения к базе
sqlite3 database.db "SELECT COUNT(*) FROM vacancies WHERE source='geekjob'"

# Тестирование парсера
cd parsers && python test_geekjob_parser.py

# Подробные логи
python run_geekjob_parser.py --verbose --pages 1
```

## 📞 Поддержка

При проблемах:
1. Проверьте логи в `parsers/geekjob_parser.log`
2. Запустите тесты: `cd parsers && python test_geekjob_parser.py`
3. Проверьте документацию: `parsers/README_GEEKJOB_PARSER.md`

---
Автоматически сгенерировано integrate_with_nextjs.py
"""
    
    readme_path = project_path / 'GEEKJOB_INTEGRATION.md'
    
    try:
        with open(readme_path, 'w', encoding='utf-8') as f:
            f.write(readme_content)
        
        print(f"✅ Создана документация: {readme_path}")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка создания документации: {e}")
        return False


def main():
    """Главная функция интеграции"""
    print("🔗 Интеграция Geekjob Parser с Next.js")
    print("Версия: 1.0")
    print("Дата: 2025-01-02")
    print("=" * 50)
    
    # Поиск Next.js проекта
    project_path = find_nextjs_project()
    if not project_path:
        print("❌ Next.js проект не найден")
        print("Запустите скрипт из папки Next.js проекта или его подпапки")
        return 1
    
    # Поиск базы данных
    db_path = find_database_file(project_path)
    
    # Проверка схемы базы данных
    if db_path.exists():
        if not check_database_schema(db_path):
            print("⚠️ Схема базы данных может быть несовместима")
            print("Парсер попытается создать недостающие колонки")
    
    # Копирование файлов парсера
    copied_files = copy_parser_files(project_path)
    if not copied_files:
        print("❌ Не удалось скопировать файлы парсера")
        return 1
    
    # Создание скрипта интеграции
    if not create_integration_script(project_path, db_path):
        print("❌ Не удалось создать скрипт интеграции")
        return 1
    
    # Обновление package.json
    create_package_json_script(project_path)
    
    # Создание документации
    create_readme_integration(project_path)
    
    print("\n" + "=" * 50)
    print("🎉 Интеграция завершена успешно!")
    print()
    print("📋 Следующие шаги:")
    print("1. Установите зависимости Python:")
    print(f"   cd {project_path}/parsers && pip install -r requirements.txt")
    print()
    print("2. Протестируйте парсер:")
    print(f"   cd {project_path} && python run_geekjob_parser.py --pages 1 --verbose")
    print()
    print("3. Запустите регулярный парсинг:")
    print(f"   cd {project_path} && python run_geekjob_parser.py")
    print("   или")
    print("   npm run parse-geekjob")
    print()
    print("4. Проверьте результаты в админ-панели:")
    print("   npm run dev")
    print("   http://localhost:3000/admin")
    print()
    print("📚 Документация:")
    print(f"   {project_path}/GEEKJOB_INTEGRATION.md")
    print(f"   {project_path}/parsers/README_GEEKJOB_PARSER.md")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
