#!/usr/bin/env python3
"""
Geekjob.ru Parser - Эффективный парсер вакансий для замены Node.js/Playwright решения

Автор: AI Assistant
Дата: 2025-01-02
Версия: 1.0

Описание:
Парсер собирает вакансии с Geekjob.ru, извлекает полную информацию
с каждой страницы вакансии и сохраняет в SQLite базу данных.
"""

import argparse
import logging
import os
import re
import sqlite3
import sys
import time
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup


class GeekjobParser:
    """Основной класс парсера Geekjob.ru"""
    
    def __init__(self, db_path: str, query: str = "дизайнер", delay: float = 1.0):
        """
        Инициализация парсера
        
        Args:
            db_path: Путь к SQLite базе данных
            query: Поисковый запрос
            delay: Задержка между запросами в секундах
        """
        self.db_path = db_path
        self.query = query
        self.delay = delay
        self.base_url = "https://geekjob.ru"
        self.search_url = f"{self.base_url}/vacancies"
        
        # Настройка сессии для HTTP запросов
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Cache-Control': 'max-age=0'
        })
        
        # Настройка логирования
        self.setup_logging()
        
        # Инициализация базы данных
        self.init_database()
        
        # Статистика
        self.stats = {
            'total_found': 0,
            'processed': 0,
            'saved': 0,
            'errors': 0,
            'skipped': 0
        }

    def setup_logging(self):
        """Настройка системы логирования"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('geekjob_parser.log', encoding='utf-8'),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger(__name__)

    def init_database(self):
        """Инициализация SQLite базы данных"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                # Проверяем существование таблицы
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT name FROM sqlite_master 
                    WHERE type='table' AND name='vacancies'
                """)
                
                if not cursor.fetchone():
                    self.logger.warning("Таблица vacancies не найдена. Создаём новую...")
                    self.create_vacancies_table(conn)
                else:
                    self.logger.info("Подключение к базе данных успешно")
                    
        except sqlite3.Error as e:
            self.logger.error(f"Ошибка подключения к базе данных: {e}")
            sys.exit(1)

    def create_vacancies_table(self, conn: sqlite3.Connection):
        """Создание таблицы vacancies если она не существует"""
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS vacancies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                external_id TEXT UNIQUE NOT NULL,
                source TEXT NOT NULL,
                url TEXT NOT NULL,
                title TEXT NOT NULL,
                company TEXT NOT NULL,
                location TEXT DEFAULT '',
                description TEXT DEFAULT '',
                salary_min INTEGER,
                salary_max INTEGER,
                salary_currency TEXT DEFAULT 'RUB',
                published_at TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                ai_specialization TEXT DEFAULT 'other',
                ai_employment TEXT DEFAULT '[]',
                ai_experience TEXT DEFAULT 'junior',
                ai_technologies TEXT DEFAULT '[]',
                ai_salary_min INTEGER,
                ai_salary_max INTEGER,
                ai_remote BOOLEAN DEFAULT 0,
                ai_relevance_score REAL DEFAULT 0,
                ai_summary TEXT DEFAULT '',
                is_approved BOOLEAN DEFAULT 0,
                is_rejected BOOLEAN DEFAULT 0,
                moderation_notes TEXT DEFAULT '',
                moderated_at TEXT,
                moderated_by TEXT DEFAULT '',
                full_description TEXT DEFAULT '',
                requirements TEXT DEFAULT '',
                tasks TEXT DEFAULT '',
                benefits TEXT DEFAULT '',
                conditions TEXT DEFAULT '',
                company_logo TEXT DEFAULT '',
                company_url TEXT DEFAULT '',
                employment_type TEXT DEFAULT '',
                experience_level TEXT DEFAULT '',
                remote_type TEXT DEFAULT ''
            )
        """)
        
        # Создаём индексы
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_external_id ON vacancies(external_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_source ON vacancies(source)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_published_at ON vacancies(published_at)")
        
        conn.commit()
        self.logger.info("Таблица vacancies создана успешно")

    def get_vacancy_urls(self, max_pages: int = 10) -> List[str]:
        """
        Получение списка URL вакансий со всех страниц поиска
        
        Args:
            max_pages: Максимальное количество страниц для парсинга
            
        Returns:
            Список URL вакансий
        """
        vacancy_urls = []
        page = 1
        
        while page <= max_pages:
            try:
                self.logger.info(f"Парсинг страницы {page} поиска...")
                
                params = {
                    'q': self.query,
                    'page': page
                }
                
                response = self.session.get(self.search_url, params=params, timeout=30)
                response.raise_for_status()
                
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Ищем ссылки на вакансии
                vacancy_links = soup.find_all('a', href=re.compile(r'/vacancy/\d+'))
                
                if not vacancy_links:
                    self.logger.info(f"На странице {page} не найдено вакансий. Завершаем поиск.")
                    break
                
                page_urls = []
                for link in vacancy_links:
                    href = link.get('href')
                    if href:
                        full_url = urljoin(self.base_url, href)
                        if full_url not in vacancy_urls:
                            vacancy_urls.append(full_url)
                            page_urls.append(full_url)
                
                self.logger.info(f"Найдено {len(page_urls)} новых вакансий на странице {page}")
                
                # Проверяем есть ли кнопка "Следующая страница"
                next_page = soup.find('a', {'class': re.compile(r'.*next.*|.*pagination.*')})
                if not next_page:
                    self.logger.info("Достигнута последняя страница поиска")
                    break
                
                page += 1
                time.sleep(self.delay)
                
            except requests.RequestException as e:
                self.logger.error(f"Ошибка при загрузке страницы {page}: {e}")
                break
            except Exception as e:
                self.logger.error(f"Неожиданная ошибка на странице {page}: {e}")
                break
        
        self.stats['total_found'] = len(vacancy_urls)
        self.logger.info(f"Всего найдено {len(vacancy_urls)} уникальных вакансий")
        return vacancy_urls

    def extract_vacancy_id(self, url: str) -> Optional[str]:
        """Извлечение ID вакансии из URL"""
        match = re.search(r'/vacancy/(\d+)', url)
        return match.group(1) if match else None

    def parse_salary(self, salary_text: str) -> Tuple[Optional[int], Optional[int], str]:
        """
        Парсинг зарплаты из текста
        
        Returns:
            Tuple[salary_min, salary_max, currency]
        """
        if not salary_text:
            return None, None, 'RUB'
        
        # Удаляем лишние пробелы и приводим к нижнему регистру
        salary_text = re.sub(r'\s+', ' ', salary_text.strip().lower())
        
        # Определяем валюту
        currency = 'RUB'
        if any(curr in salary_text for curr in ['$', 'usd', 'долл']):
            currency = 'USD'
        elif any(curr in salary_text for curr in ['€', 'eur', 'евро']):
            currency = 'EUR'
        
        # Ищем числа
        numbers = re.findall(r'(\d+(?:\s*\d+)*)', salary_text)
        if not numbers:
            return None, None, currency
        
        # Очищаем числа от пробелов и конвертируем
        clean_numbers = []
        for num in numbers:
            clean_num = int(re.sub(r'\s+', '', num))
            clean_numbers.append(clean_num)
        
        if len(clean_numbers) == 1:
            # Одно число - может быть "от X" или "до X"
            if any(word in salary_text for word in ['от', 'from']):
                return clean_numbers[0], None, currency
            elif any(word in salary_text for word in ['до', 'to']):
                return None, clean_numbers[0], currency
            else:
                return clean_numbers[0], clean_numbers[0], currency
        elif len(clean_numbers) >= 2:
            # Два числа - диапазон
            return min(clean_numbers), max(clean_numbers), currency
        
        return None, None, currency

    def extract_text_by_keywords(self, soup: BeautifulSoup, keywords: List[str]) -> str:
        """
        Извлечение текста по ключевым словам в заголовках
        
        Args:
            soup: BeautifulSoup объект страницы
            keywords: Список ключевых слов для поиска
            
        Returns:
            Найденный текст или пустая строка
        """
        for keyword in keywords:
            # Ищем заголовки с ключевыми словами
            headers = soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'strong', 'b'], 
                                   string=re.compile(keyword, re.IGNORECASE))
            
            for header in headers:
                # Ищем следующий элемент с текстом
                next_element = header.find_next_sibling()
                if next_element:
                    text = next_element.get_text(strip=True)
                    if text and len(text) > 10:
                        return text
                
                # Ищем родительский элемент и берём текст после заголовка
                parent = header.parent
                if parent:
                    full_text = parent.get_text()
                    # Разделяем по заголовку и берём часть после
                    parts = full_text.split(header.get_text(), 1)
                    if len(parts) > 1:
                        after_header = parts[1].strip()
                        if after_header and len(after_header) > 10:
                            return after_header[:500]  # Ограничиваем длину
        
        return ''

    def parse_vacancy_details(self, url: str) -> Optional[Dict]:
        """
        Парсинг детальной информации о вакансии
        
        Args:
            url: URL вакансии
            
        Returns:
            Словарь с данными вакансии или None в случае ошибки
        """
        try:
            self.logger.debug(f"Парсинг вакансии: {url}")
            
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Извлекаем ID вакансии
            external_id = self.extract_vacancy_id(url)
            if not external_id:
                self.logger.warning(f"Не удалось извлечь ID из URL: {url}")
                return None
            
            # Извлекаем основную информацию
            vacancy_data = {
                'external_id': f"geekjob_{external_id}",
                'source': 'geekjob',
                'url': url,
                'title': '',
                'company': '',
                'location': '',
                'description': '',
                'full_description': '',
                'requirements': '',
                'tasks': '',
                'benefits': '',
                'conditions': '',
                'salary_min': None,
                'salary_max': None,
                'salary_currency': 'RUB',
                'published_at': datetime.now().isoformat(),
                'company_logo': '',
                'company_url': '',
                'employment_type': '',
                'experience_level': '',
                'remote_type': ''
            }
            
            # Заголовок вакансии
            title_selectors = [
                'h1.vacancy-title',
                'h1[class*="title"]',
                '.vacancy-header h1',
                'h1',
                '.job-title',
                '[data-testid="vacancy-title"]'
            ]
            
            for selector in title_selectors:
                title_elem = soup.select_one(selector)
                if title_elem:
                    vacancy_data['title'] = title_elem.get_text(strip=True)
                    break
            
            # Название компании
            company_selectors = [
                '.company-name',
                '[class*="company"]',
                '.vacancy-company',
                '.employer-name',
                'a[href*="/company/"]'
            ]
            
            for selector in company_selectors:
                company_elem = soup.select_one(selector)
                if company_elem:
                    vacancy_data['company'] = company_elem.get_text(strip=True)
                    # Извлекаем URL компании
                    if company_elem.name == 'a':
                        company_href = company_elem.get('href')
                        if company_href:
                            vacancy_data['company_url'] = urljoin(self.base_url, company_href)
                    break
            
            # Локация
            location_selectors = [
                '.location',
                '.city',
                '[class*="location"]',
                '.vacancy-location'
            ]
            
            for selector in location_selectors:
                location_elem = soup.select_one(selector)
                if location_elem:
                    vacancy_data['location'] = location_elem.get_text(strip=True)
                    break
            
            # Зарплата
            salary_selectors = [
                '.salary',
                '[class*="salary"]',
                '.wage',
                '.compensation'
            ]
            
            for selector in salary_selectors:
                salary_elem = soup.select_one(selector)
                if salary_elem:
                    salary_text = salary_elem.get_text(strip=True)
                    salary_min, salary_max, currency = self.parse_salary(salary_text)
                    vacancy_data['salary_min'] = salary_min
                    vacancy_data['salary_max'] = salary_max
                    vacancy_data['salary_currency'] = currency
                    break
            
            # Полное описание вакансии
            description_selectors = [
                '.vacancy-description',
                '.job-description',
                '[class*="description"]',
                '.vacancy-content',
                '.job-content',
                '.content'
            ]
            
            for selector in description_selectors:
                desc_elem = soup.select_one(selector)
                if desc_elem:
                    full_desc = desc_elem.get_text(separator='\n', strip=True)
                    vacancy_data['full_description'] = full_desc
                    # Краткое описание - первые 300 символов
                    vacancy_data['description'] = full_desc[:300] + '...' if len(full_desc) > 300 else full_desc
                    break
            
            # Если не нашли описание, берём весь текст страницы (исключая навигацию)
            if not vacancy_data['full_description']:
                # Удаляем навигационные элементы
                for nav in soup.find_all(['nav', 'header', 'footer', 'aside']):
                    nav.decompose()
                
                main_content = soup.find('main') or soup.find('body')
                if main_content:
                    vacancy_data['full_description'] = main_content.get_text(separator='\n', strip=True)
                    vacancy_data['description'] = vacancy_data['full_description'][:300] + '...'
            
            # Требования
            requirements_keywords = ['требования', 'требуется', 'необходимо', 'обязательно', 'must have', 'requirements']
            vacancy_data['requirements'] = self.extract_text_by_keywords(soup, requirements_keywords)
            
            # Задачи/обязанности
            tasks_keywords = ['задачи', 'обязанности', 'функции', 'что делать', 'responsibilities', 'duties']
            vacancy_data['tasks'] = self.extract_text_by_keywords(soup, tasks_keywords)
            
            # Условия
            conditions_keywords = ['условия', 'что предлагаем', 'условия работы', 'conditions', 'what we offer']
            vacancy_data['conditions'] = self.extract_text_by_keywords(soup, conditions_keywords)
            
            # Преимущества/льготы
            benefits_keywords = ['преимущества', 'льготы', 'бонусы', 'мы предлагаем', 'benefits', 'perks']
            vacancy_data['benefits'] = self.extract_text_by_keywords(soup, benefits_keywords)
            
            # Тип занятости
            employment_keywords = ['полная занятость', 'частичная занятость', 'проектная работа', 'стажировка']
            for keyword in employment_keywords:
                if keyword.lower() in vacancy_data['full_description'].lower():
                    vacancy_data['employment_type'] = keyword
                    break
            
            # Удалённая работа
            if any(word in vacancy_data['full_description'].lower() for word in ['удаленно', 'remote', 'дистанционно']):
                vacancy_data['remote_type'] = 'remote'
            elif any(word in vacancy_data['full_description'].lower() for word in ['офис', 'office']):
                vacancy_data['remote_type'] = 'office'
            else:
                vacancy_data['remote_type'] = 'hybrid'
            
            # Логотип компании
            logo_selectors = [
                '.company-logo img',
                '.logo img',
                '[class*="logo"] img'
            ]
            
            for selector in logo_selectors:
                logo_elem = soup.select_one(selector)
                if logo_elem:
                    logo_src = logo_elem.get('src')
                    if logo_src:
                        vacancy_data['company_logo'] = urljoin(self.base_url, logo_src)
                    break
            
            # Проверяем обязательные поля
            if not vacancy_data['title'] or not vacancy_data['company']:
                self.logger.warning(f"Отсутствуют обязательные поля для вакансии {url}")
                return None
            
            return vacancy_data
            
        except requests.RequestException as e:
            self.logger.error(f"Ошибка HTTP при парсинге {url}: {e}")
            return None
        except Exception as e:
            self.logger.error(f"Ошибка при парсинге {url}: {e}")
            return None

    def save_vacancy(self, vacancy_data: Dict) -> bool:
        """
        Сохранение вакансии в базу данных
        
        Args:
            vacancy_data: Данные вакансии
            
        Returns:
            True если сохранение успешно, False иначе
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Используем INSERT OR REPLACE для обновления существующих записей
                cursor.execute("""
                    INSERT OR REPLACE INTO vacancies (
                        external_id, source, url, title, company, location, description,
                        salary_min, salary_max, salary_currency, published_at,
                        full_description, requirements, tasks, benefits, conditions,
                        company_logo, company_url, employment_type, experience_level, remote_type,
                        updated_at
                    ) VALUES (
                        ?, ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?,
                        ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?,
                        CURRENT_TIMESTAMP
                    )
                """, (
                    vacancy_data['external_id'],
                    vacancy_data['source'],
                    vacancy_data['url'],
                    vacancy_data['title'],
                    vacancy_data['company'],
                    vacancy_data['location'],
                    vacancy_data['description'],
                    vacancy_data['salary_min'],
                    vacancy_data['salary_max'],
                    vacancy_data['salary_currency'],
                    vacancy_data['published_at'],
                    vacancy_data['full_description'],
                    vacancy_data['requirements'],
                    vacancy_data['tasks'],
                    vacancy_data['benefits'],
                    vacancy_data['conditions'],
                    vacancy_data['company_logo'],
                    vacancy_data['company_url'],
                    vacancy_data['employment_type'],
                    vacancy_data['experience_level'],
                    vacancy_data['remote_type']
                ))
                
                conn.commit()
                return True
                
        except sqlite3.Error as e:
            self.logger.error(f"Ошибка сохранения в БД: {e}")
            return False

    def run(self, max_pages: int = 10) -> Dict:
        """
        Запуск парсера
        
        Args:
            max_pages: Максимальное количество страниц для парсинга
            
        Returns:
            Статистика выполнения
        """
        start_time = time.time()
        self.logger.info(f"Запуск парсера Geekjob.ru с запросом: '{self.query}'")
        
        # Получаем список URL вакансий
        vacancy_urls = self.get_vacancy_urls(max_pages)
        
        if not vacancy_urls:
            self.logger.warning("Не найдено ни одной вакансии")
            return self.stats
        
        # Парсим каждую вакансию
        for i, url in enumerate(vacancy_urls, 1):
            try:
                self.logger.info(f"Обработка вакансии {i}/{len(vacancy_urls)}: {url}")
                
                # Парсим детали вакансии
                vacancy_data = self.parse_vacancy_details(url)
                
                if vacancy_data:
                    # Сохраняем в базу данных
                    if self.save_vacancy(vacancy_data):
                        self.stats['saved'] += 1
                        self.logger.info(f"✅ Сохранена: {vacancy_data['title']} - {vacancy_data['company']}")
                    else:
                        self.stats['errors'] += 1
                        self.logger.error(f"❌ Ошибка сохранения: {url}")
                else:
                    self.stats['skipped'] += 1
                    self.logger.warning(f"⚠️ Пропущена (ошибка парсинга): {url}")
                
                self.stats['processed'] += 1
                
                # Задержка между запросами
                if i < len(vacancy_urls):
                    time.sleep(self.delay)
                    
            except KeyboardInterrupt:
                self.logger.info("Получен сигнал прерывания. Завершение работы...")
                break
            except Exception as e:
                self.stats['errors'] += 1
                self.logger.error(f"Неожиданная ошибка при обработке {url}: {e}")
        
        # Финальная статистика
        end_time = time.time()
        duration = end_time - start_time
        
        self.logger.info("=" * 50)
        self.logger.info("СТАТИСТИКА ВЫПОЛНЕНИЯ:")
        self.logger.info(f"Найдено вакансий: {self.stats['total_found']}")
        self.logger.info(f"Обработано: {self.stats['processed']}")
        self.logger.info(f"Сохранено: {self.stats['saved']}")
        self.logger.info(f"Пропущено: {self.stats['skipped']}")
        self.logger.info(f"Ошибок: {self.stats['errors']}")
        self.logger.info(f"Время выполнения: {duration:.2f} секунд")
        self.logger.info("=" * 50)
        
        return self.stats


def main():
    """Главная функция"""
    parser = argparse.ArgumentParser(
        description="Парсер вакансий Geekjob.ru",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Примеры использования:
  python geekjob_parser.py --db database.db --query "python разработчик"
  python geekjob_parser.py --db /path/to/database.db --pages 5 --delay 2.0
  python geekjob_parser.py --help
        """
    )
    
    parser.add_argument(
        '--db', '--database',
        type=str,
        default=os.getenv('DATABASE_PATH', 'database.db'),
        help='Путь к SQLite базе данных (по умолчанию: database.db)'
    )
    
    parser.add_argument(
        '--query', '-q',
        type=str,
        default='дизайнер',
        help='Поисковый запрос (по умолчанию: дизайнер)'
    )
    
    parser.add_argument(
        '--pages', '-p',
        type=int,
        default=10,
        help='Максимальное количество страниц для парсинга (по умолчанию: 10)'
    )
    
    parser.add_argument(
        '--delay', '-d',
        type=float,
        default=1.0,
        help='Задержка между запросами в секундах (по умолчанию: 1.0)'
    )
    
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Подробный вывод (DEBUG уровень логирования)'
    )
    
    args = parser.parse_args()
    
    # Настройка уровня логирования
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Проверка существования базы данных
    if not os.path.exists(args.db):
        print(f"⚠️ База данных {args.db} не найдена. Будет создана новая.")
    
    try:
        # Создание и запуск парсера
        geekjob_parser = GeekjobParser(
            db_path=args.db,
            query=args.query,
            delay=args.delay
        )
        
        stats = geekjob_parser.run(max_pages=args.pages)
        
        # Возвращаем код выхода в зависимости от результата
        if stats['errors'] > stats['saved']:
            sys.exit(1)  # Больше ошибок чем успешных сохранений
        else:
            sys.exit(0)  # Успешное выполнение
            
    except KeyboardInterrupt:
        print("\n⚠️ Выполнение прервано пользователем")
        sys.exit(130)
    except Exception as e:
        print(f"❌ Критическая ошибка: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
